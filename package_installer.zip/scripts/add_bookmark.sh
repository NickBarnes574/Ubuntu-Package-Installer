#!/bin/bash

# Define the path to your Firefox profile database
PROFILE_DB="$HOME/.mozilla/firefox/*.default/places.sqlite"

# Define the bookmark data
URL="$1"
TITLE="$2"
FOLDER="$3"

# Use sqlite3 to add the bookmark to the database
sqlite3 "$PROFILE_DB" "INSERT INTO moz_bookmarks (type, fk, parent, position, title, dateAdded, lastModified) VALUES (1, (SELECT id FROM moz_places WHERE url='$URL'), (SELECT id FROM moz_bookmarks WHERE title='Bookmarks Toolbar' AND type=1), (SELECT COALESCE(MAX(position)+1,0) FROM moz_bookmarks WHERE parent=(SELECT id FROM moz_bookmarks WHERE title='Bookmarks Toolbar' AND type=1)), '$TITLE', strftime('%s','now'), strftime('%s','now'));"

echo "Bookmark added to Firefox"
